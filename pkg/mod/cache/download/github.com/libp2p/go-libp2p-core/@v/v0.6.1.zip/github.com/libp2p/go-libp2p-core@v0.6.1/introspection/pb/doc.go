// Package introspection/pb contains the protobuf definitions and objects for
// that form the libp2p introspection protocol.
package pb

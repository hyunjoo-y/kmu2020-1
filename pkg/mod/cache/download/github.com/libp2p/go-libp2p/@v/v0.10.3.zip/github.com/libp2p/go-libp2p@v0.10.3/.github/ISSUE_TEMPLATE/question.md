---
name: 'Question/Support'
about: 'Ask a question about go-libp2p or request support.'
labels: question, invalid
---

This bug tracker is only for actionable bug reports and feature requests. Please direct any questions to https://discuss.libp2p.io or to our Matrix (#libp2p:matrix.org) or IRC (#libp2p on freenode) channels.

If you don't get an immediate response, please keep trying.

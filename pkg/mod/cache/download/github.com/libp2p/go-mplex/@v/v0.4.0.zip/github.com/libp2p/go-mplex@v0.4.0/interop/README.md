# Js/Go interop test

This directory contains a basic js/go interop test. To run it, just run
`./test.sh` in this directory. It depends on `npm` and `go`.

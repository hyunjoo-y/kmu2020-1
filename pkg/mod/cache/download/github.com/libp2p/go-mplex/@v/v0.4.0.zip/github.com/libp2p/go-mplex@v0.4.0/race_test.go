//go:build race
// +build race

package multiplex

var raceEnabled = true

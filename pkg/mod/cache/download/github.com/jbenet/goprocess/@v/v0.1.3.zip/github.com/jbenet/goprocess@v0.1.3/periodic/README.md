# goprocess/periodic - periodic process creation

- goprocess: https://github.com/jbenet/goprocess
- Godoc: https://godoc.org/github.com/jbenet/goprocess/periodic
